import { useState } from "react";

/* ═══════════════════════════════════════════════════════
   PROXA TUTOR — Client Demo Walkthrough
   Interactive guided tour addressing all client questions
   ═══════════════════════════════════════════════════════ */

const C = {
  bg:"#06080C", panel:"#0B0E15", card:"#11141D", cardR:"#161A26",
  cardH:"#1A1F2D", surface:"#1D2233",
  border:"#1C2035", borderL:"#252B42", borderF:"#4A7CFF",
  blue:"#4A7CFF", blueD:"#3A63CC", blueG:"rgba(74,124,255,.08)",
  emerald:"#10B981", emeraldD:"rgba(16,185,129,.10)",
  amber:"#F59E0B", amberD:"rgba(245,158,11,.10)",
  rose:"#EF4444", roseD:"rgba(239,68,68,.10)",
  violet:"#8B5CF6", violetD:"rgba(139,92,246,.10)",
  teal:"#14B8A6", tealD:"rgba(20,184,166,.10)",
  orange:"#F97316",
  text:"#E4E8F1", soft:"#9CA3B8", muted:"#636B82", faint:"#3E4459",
  white:"#FFF", glass:"rgba(255,255,255,.03)",
};

const Badge = ({children,color=C.blue,bg})=>(
  <span style={{display:"inline-flex",alignItems:"center",gap:4,padding:"3px 10px",borderRadius:6,fontSize:10.5,fontWeight:600,letterSpacing:.4,color,background:bg||`${color}14`,whiteSpace:"nowrap",fontFamily:"'Outfit',sans-serif"}}>{children}</span>
);

const Bar = ({value,color=C.blue,h=5})=>(
  <div style={{width:"100%",height:h,borderRadius:h,background:`${color}12`,overflow:"hidden"}}>
    <div style={{height:"100%",borderRadius:h,background:`linear-gradient(90deg,${color}CC,${color})`,width:`${value}%`,transition:"width .8s ease"}}/>
  </div>
);

const Ring = ({value,size=44,stroke=4,color=C.blue,children})=>{
  const r=(size-stroke)/2,c=2*Math.PI*r,o=c-(value/100)*c;
  return(
    <div style={{position:"relative",width:size,height:size}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)"}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={`${color}15`} strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={c} strokeDashoffset={o} strokeLinecap="round" style={{transition:"stroke-dashoffset 1s ease"}}/>
      </svg>
      {children&&<div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>{children}</div>}
    </div>
  );
};

// ═══ DEMO SECTIONS ═══
const sections = [
  {
    id:"intro",
    num:"",
    title:"Proxa Tutor",
    subtitle:"Interactive Platform Demo",
    clientQ:null,
  },
  {
    id:"q1",
    num:"01",
    title:"Competency-to-Role Mapping",
    subtitle:"How capabilities and competencies are mapped to specific roles",
    clientQ:"Could you please walk us through how capabilities and competencies are mapped to specific roles within the solution?",
  },
  {
    id:"q2",
    num:"02",
    title:"Scoring Pattern & Behavioral Rubrics",
    subtitle:"What scale is used, and what defined behaviors are expected",
    clientQ:"It would also be great to see how the scoring pattern works—what scale is used, and what defined behaviors are expected to be observed to ensure consistent assessment.",
  },
  {
    id:"q3",
    num:"03",
    title:"AI-Driven Next Steps & Objectives",
    subtitle:"Does the system prompt users with suggested next steps?",
    clientQ:"When an assessment is completed, does the system prompt users with suggested next steps or objectives to set?",
  },
  {
    id:"q4",
    num:"04",
    title:"Self-Evaluation & Manager Assessment",
    subtitle:"Navigation for self-eval, manager-driven assessment, and gap analysis",
    clientQ:"How the navigation works for both self-evaluation and manager-driven assessment, along with any gap analysis features.",
  },
  {
    id:"q5",
    num:"05",
    title:"Progress Tracking Toward Goals",
    subtitle:"How do we monitor movement from assessments toward goals?",
    clientQ:"How progress can be tracked—how do we monitor movement from assessments toward goals?",
  },
  {
    id:"q6",
    num:"06",
    title:"Reporting at Every Level",
    subtitle:"Individual, group, team, and country-level reporting",
    clientQ:"What reporting is available for individuals, groups, teams, or even by country?",
  },
  {
    id:"q7",
    num:"07",
    title:"CRM Integration & Triggers",
    subtitle:"Can actions be triggered directly from CRM?",
    clientQ:"Connection to other platform, e.g can actions be triggered directly from CRM?",
  },
  {
    id:"closing",
    num:"",
    title:"Why Proxa Tutor",
    subtitle:"The Intelligent Capability Development Platform",
    clientQ:null,
  },
];

// ═══ SECTION CONTENT RENDERERS ═══

const IntroSlide = () => (
  <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:420,textAlign:"center",animation:"fadeUp .5s ease"}}>
    <div style={{position:"relative",marginBottom:28}}>
      <div style={{position:"absolute",inset:-16,borderRadius:28,background:`radial-gradient(circle,${C.blue}15,transparent 70%)`,animation:"pulse 3s ease infinite"}}/>
      <div style={{width:72,height:72,borderRadius:20,background:`linear-gradient(135deg,${C.blue},${C.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,fontWeight:800,color:C.white,position:"relative",boxShadow:`0 8px 40px ${C.blue}30`}}>P</div>
    </div>
    <h1 style={{fontSize:38,fontWeight:800,color:C.text,margin:"0 0 8px",letterSpacing:-1.5}}>Proxa Tutor</h1>
    <p style={{fontSize:18,color:C.soft,margin:"0 0 6px"}}>Intelligent Capability Development Platform</p>
    <p style={{fontSize:14,color:C.muted,margin:"0 0 32px"}}>by Proxa Labs</p>
    <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center",marginBottom:28}}>
      {["AI-Native Tutoring","Closed-Loop Certification","Adaptive Learning","Predictive Analytics","Echo Roleplay Integration"].map((t,i)=>(
        <Badge key={i} color={[C.blue,C.emerald,C.violet,C.teal,C.rose][i]}>{t}</Badge>
      ))}
    </div>
    <p style={{fontSize:13,color:C.muted,maxWidth:500,lineHeight:1.6}}>
      This interactive walkthrough addresses each of your specific questions about the Proxa Tutor platform. Use the navigation to explore each topic.
    </p>
  </div>
);

const Q1Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      Proxa Tutor supports <strong style={{color:C.text}}>role-specific competency frameworks</strong> — each role in your organization has its own set of competencies, weights, sub-competencies, and assessment sources configured by an administrator.
    </p>

    {/* Role Selector Demo */}
    <div style={{background:C.card,borderRadius:14,padding:"18px 22px",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:10,fontWeight:600,color:C.teal,textTransform:"uppercase",letterSpacing:.8,marginBottom:12}}>Role-Specific Competency Frameworks</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,marginBottom:16}}>
        {[
          {role:"Specialty Sales Rep",count:6,users:612,active:true},
          {role:"Key Account Manager",count:5,users:89,active:false},
          {role:"Medical Science Liaison",count:7,users:64,active:false},
          {role:"Field Trainer",count:4,users:28,active:false},
        ].map((r,i)=>(
          <div key={i} style={{padding:"12px",borderRadius:10,textAlign:"center",border:`1.5px solid ${r.active?C.teal+"40":C.border}`,background:r.active?`${C.teal}08`:C.cardR}}>
            <div style={{fontSize:12,fontWeight:600,color:r.active?C.teal:C.text}}>{r.role}</div>
            <div style={{fontSize:10,color:C.muted,marginTop:3}}>{r.count} competencies · {r.users} users</div>
          </div>
        ))}
      </div>

      {/* Specialty Rep Framework */}
      <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:10}}>Specialty Sales Rep — Competency Framework</div>
      {[
        {name:"Clinical Knowledge",weight:25,threshold:70,color:C.emerald,subs:"MOA, Trial Data, Safety, Disease State"},
        {name:"Competitive Positioning",weight:30,threshold:65,color:C.amber,subs:"MOA Differentiation, Head-to-Head, Formulary, Messaging"},
        {name:"Objection Handling",weight:20,threshold:65,color:C.amber,subs:"HCP Clinical, Payer, Competitive, Patient Compliance"},
        {name:"Selling Skills",weight:15,threshold:70,color:C.blue,subs:"Probing, Storytelling, Closing, Call Planning"},
        {name:"Regulatory Compliance",weight:10,threshold:85,color:C.emerald,subs:"On-Label, AE Reporting, Fair Balance, Ethics"},
      ].map((c,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:12,padding:"8px 0",borderBottom:i<4?`1px solid ${C.border}`:"none"}}>
          <Ring value={c.weight} size={34} stroke={3} color={c.color}><span style={{fontSize:9,fontWeight:700,color:c.color}}>{c.weight}%</span></Ring>
          <div style={{flex:1}}>
            <div style={{fontSize:12,fontWeight:600,color:C.text}}>{c.name}</div>
            <div style={{fontSize:10,color:C.muted}}>{c.subs}</div>
          </div>
          <span style={{fontSize:10,color:C.muted}}>Threshold: {c.threshold}%</span>
        </div>
      ))}
    </div>

    <div style={{background:`${C.teal}08`,borderRadius:10,padding:"12px 16px",border:`1px solid ${C.teal}15`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.teal,marginBottom:4}}>Key Capability</div>
      <div style={{fontSize:12,color:C.soft,lineHeight:1.6}}>Each role has independently configurable competency weights that sum to 100%. An administrator can create, edit, and assign different frameworks to different roles — ensuring a specialty rep is assessed differently than an MSL or KAM.</div>
    </div>
  </div>
);

const Q2Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      Every competency has a <strong style={{color:C.text}}>4-level behavioral scoring rubric</strong> that defines exactly what observable behaviors correspond to each proficiency level. This ensures consistent, objective assessment across the organization.
    </p>

    <div style={{background:C.card,borderRadius:14,overflow:"hidden",border:`1px solid ${C.border}`}}>
      <div style={{padding:"12px 18px",background:`${C.teal}06`,borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:6}}>
        <span style={{fontSize:11,fontWeight:600,color:C.teal}}>Behavioral Scoring Rubric — Competitive Positioning</span>
      </div>
      {[
        {level:"Expert",range:"90–100%",color:C.emerald,desc:"Proactively addresses competitive data. Uses Acknowledge→Bridge→Seed framework naturally. Leads with differentiated value without being prompted."},
        {level:"Proficient",range:"70–89%",color:C.blue,desc:"Can differentiate product vs competitors when asked. Acknowledges competitive strengths before pivoting. Occasionally misses optimal bridging opportunities."},
        {level:"Developing",range:"50–69%",color:C.amber,desc:"Knows key competitive differences but gets defensive when challenged. Avoids or dismisses competitor data rather than acknowledging it."},
        {level:"Needs Improvement",range:"< 50%",color:C.rose,desc:"Cannot articulate meaningful differentiation. Gets flustered by competitive challenges. Defaults to price or availability arguments."},
      ].map((r,i)=>(
        <div key={i} style={{padding:"14px 18px",borderBottom:i<3?`1px solid ${C.border}`:"none",display:"flex",gap:14,alignItems:"flex-start"}}>
          <div style={{minWidth:90}}><Badge color={r.color}>{r.level}</Badge><div style={{fontSize:9.5,color:C.muted,marginTop:4}}>{r.range}</div></div>
          <div style={{fontSize:12,color:C.soft,lineHeight:1.6}}>{r.desc}</div>
        </div>
      ))}
    </div>

    {/* Rep-facing scale */}
    <div style={{background:C.card,borderRadius:12,padding:"14px 18px",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:10}}>Reps also see the scoring scale in their Competency view:</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:0}}>
        {[{l:"Expert",r:"90–100%",c:C.emerald,d:"Mastery in live scenarios"},{l:"Proficient",r:"70–89%",c:C.blue,d:"Consistent execution"},{l:"Developing",r:"50–69%",c:C.amber,d:"Struggles under pressure"},{l:"Gap",r:"< 50%",c:C.rose,d:"Remediation required"}].map((r,i)=>(
          <div key={i} style={{padding:"10px",textAlign:"center",borderRight:i<3?`1px solid ${C.border}`:"none"}}>
            <div style={{fontSize:11,fontWeight:700,color:r.c}}>{r.l}</div>
            <div style={{fontSize:9.5,color:C.muted}}>{r.r}</div>
            <div style={{fontSize:9.5,color:C.faint,marginTop:3}}>{r.d}</div>
          </div>
        ))}
      </div>
    </div>

    <div style={{background:`${C.violet}08`,borderRadius:10,padding:"12px 16px",border:`1px solid ${C.violet}15`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.violet,marginBottom:4}}>Assessment Sources</div>
      <div style={{fontSize:12,color:C.soft,lineHeight:1.6}}>Scores are derived from multiple sources — Echo AI roleplay sessions, adaptive quizzes, AI Tutor coaching scores, course completions, and manager field observations — providing a multi-dimensional, bias-resistant assessment.</div>
    </div>
  </div>
);

const Q3Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      <strong style={{color:C.emerald}}>Yes — this is one of Proxa Tutor's strongest differentiators.</strong> The system automatically generates personalized next steps at every stage of the learning journey, powered by AI.
    </p>

    <div style={{background:C.card,borderRadius:14,padding:"18px 22px",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.blue,textTransform:"uppercase",letterSpacing:.8,marginBottom:14}}>The Closed-Loop: Assessment → AI Next Steps → Action</div>

      {[
        {step:"1",title:"Echo Roleplay Failure",desc:"Rep scores 54% on Ozempic® Competitive Intelligence (below 75% threshold)",icon:"🎭",color:C.rose},
        {step:"2",title:"AI Gap Analysis Generated",desc:"System identifies 3 specific competency gaps: MOA Differentiation (38%), Payer Objections (45%), RWE Fluency (62%)",icon:"📊",color:C.amber},
        {step:"3",title:"Personalized Pathway Created",desc:"AI generates a 9-step remediation pathway — courses, AI modules, adaptive quizzes, AI Tutor sessions — all targeted at the specific gaps",icon:"🎯",color:C.blue},
        {step:"4",title:"AI Tutor Coaches Throughout",desc:"An always-available AI Tutor provides gap-aware coaching, practice HCP simulations, and adaptive quizzes personalized to the rep's weaknesses",icon:"⚡",color:C.violet},
        {step:"5",title:"AI Predicts Readiness",desc:"When the system predicts the rep is ready (readiness score ≥75%), it recommends re-attempting the Echo certification",icon:"✅",color:C.emerald},
      ].map((s,i)=>(
        <div key={i} style={{display:"flex",gap:12,alignItems:"flex-start",marginBottom:i<4?12:0}}>
          <div style={{width:32,height:32,borderRadius:8,background:`${s.color}12`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{s.icon}</div>
          <div>
            <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:2}}>
              <span style={{fontSize:12,fontWeight:700,color:s.color}}>Step {s.step}</span>
              <span style={{fontSize:12,fontWeight:600,color:C.text}}>{s.title}</span>
            </div>
            <div style={{fontSize:12,color:C.soft,lineHeight:1.5}}>{s.desc}</div>
          </div>
        </div>
      ))}
    </div>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
      <div style={{background:`${C.emerald}08`,borderRadius:10,padding:"12px 16px",border:`1px solid ${C.emerald}15`}}>
        <div style={{fontSize:10,fontWeight:600,color:C.emerald,textTransform:"uppercase",letterSpacing:.6,marginBottom:6}}>For the Rep</div>
        <div style={{fontSize:11.5,color:C.soft,lineHeight:1.6}}>Dashboard alerts, pathway progress, AI Tutor recommendations, readiness predictions, and coaching assignments from their manager — all surface as actionable next steps.</div>
      </div>
      <div style={{background:`${C.violet}08`,borderRadius:10,padding:"12px 16px",border:`1px solid ${C.violet}15`}}>
        <div style={{fontSize:10,fontWeight:600,color:C.violet,textTransform:"uppercase",letterSpacing:.6,marginBottom:6}}>For the Manager</div>
        <div style={{fontSize:11.5,color:C.soft,lineHeight:1.6}}>AI-generated coaching agendas, at-risk alerts, intervention recommendations, and predictive insights tell managers exactly who to coach, on what, and when.</div>
      </div>
    </div>
  </div>
);

const Q4Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      The platform provides distinct but connected experiences for <strong style={{color:C.blue}}>self-evaluation (rep)</strong> and <strong style={{color:C.violet}}>manager-driven assessment</strong>, with robust gap analysis throughout.
    </p>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
      {/* Rep Self-Eval */}
      <div style={{background:C.card,borderRadius:14,padding:"18px 20px",border:`1px solid ${C.blue}15`}}>
        <div style={{fontSize:11,fontWeight:600,color:C.blue,textTransform:"uppercase",letterSpacing:.8,marginBottom:12}}>Rep Self-Assessment Path</div>
        {["Competencies view — 6 areas with 24 sub-competencies, each with score + rubric","Per-competency AI quizzes — 5-question adaptive assessments with immediate feedback","AI Tutor — Gap-Aware mode knows exact weaknesses, coaches accordingly","Performance Insights — Readiness radar, peer benchmarks, growth tracking","Coaching Hub — Weekly coaching plans with self-reflection prompts"].map((f,i)=>(
          <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:8}}>
            <span style={{color:C.blue,fontSize:9,marginTop:4}}>●</span>
            <span style={{fontSize:11.5,color:C.soft,lineHeight:1.5}}>{f}</span>
          </div>
        ))}
      </div>

      {/* Manager Assessment */}
      <div style={{background:C.card,borderRadius:14,padding:"18px 20px",border:`1px solid ${C.violet}15`}}>
        <div style={{fontSize:11,fontWeight:600,color:C.violet,textTransform:"uppercase",letterSpacing:.8,marginBottom:12}}>Manager Assessment Path</div>
        {["My Reps — Full team table with drill-down to individual gap profiles","Field Observation Form — 5-dimension rating after ride-alongs (1-5 scale)","Send Coaching Notes — Surface directly in rep's Coaching Hub + Notifications","Assign AI Tutor Sessions — Mandatory practice assignments for specific gaps","Team Competency Heatmap — Systemic gap identification across the team"].map((f,i)=>(
          <div key={i} style={{display:"flex",gap:8,alignItems:"flex-start",marginBottom:8}}>
            <span style={{color:C.violet,fontSize:9,marginTop:4}}>●</span>
            <span style={{fontSize:11.5,color:C.soft,lineHeight:1.5}}>{f}</span>
          </div>
        ))}
      </div>
    </div>

    <div style={{background:C.card,borderRadius:12,padding:"14px 18px",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.rose,marginBottom:8}}>Gap Analysis — Multi-Source, Continuous</div>
      <div style={{display:"flex",gap:10}}>
        {["Echo Roleplay AI Scoring","Adaptive Quiz Performance","AI Tutor Coaching Scores","Manager Field Observations","Course/Module Completion"].map((s,i)=>(
          <Badge key={i} color={[C.rose,C.blue,C.violet,C.emerald,C.teal][i]}>{s}</Badge>
        ))}
      </div>
      <div style={{fontSize:11.5,color:C.muted,marginTop:8}}>All sources feed into a unified competency score — no single assessment determines the rating.</div>
    </div>
  </div>
);

const Q5Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      Progress tracking is layered across multiple views, from <strong style={{color:C.text}}>daily activity</strong> to <strong style={{color:C.text}}>long-term competency growth</strong> to <strong style={{color:C.text}}>AI-predicted readiness</strong>.
    </p>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
      {[
        {title:"My Pathway",desc:"Step-by-step remediation progress. Visual timeline showing completed steps, current step, and locked future steps. Percentage complete with time estimate.",color:C.blue,icon:"🎯"},
        {title:"Performance Insights",desc:"Competency growth over time (start → current with deltas). Echo score trends by month. Peer benchmarking. AI Readiness prediction with projected date.",color:C.emerald,icon:"📊"},
        {title:"Achievements",desc:"Milestone tracking with progress bars. XP leaderboard (weekly + all-time). Learning streaks. Full development journey timeline.",color:C.orange,icon:"🏆"},
      ].map((v,i)=>(
        <div key={i} style={{background:C.card,borderRadius:14,padding:"18px 18px",border:`1px solid ${C.border}`}}>
          <div style={{fontSize:22,marginBottom:8}}>{v.icon}</div>
          <div style={{fontSize:13,fontWeight:600,color:v.color,marginBottom:6}}>{v.title}</div>
          <div style={{fontSize:11.5,color:C.soft,lineHeight:1.6}}>{v.desc}</div>
        </div>
      ))}
    </div>

    {/* AI Readiness Demo */}
    <div style={{background:C.card,borderRadius:14,padding:"18px 22px",border:`1px solid ${C.border}`,display:"flex",gap:20,alignItems:"center"}}>
      <Ring value={68} size={70} stroke={5} color={C.amber}>
        <span style={{fontSize:20,fontWeight:800,color:C.amber,fontFamily:"'Outfit',sans-serif"}}>68</span>
      </Ring>
      <div style={{flex:1}}>
        <div style={{fontSize:12,fontWeight:600,color:C.amber,marginBottom:4}}>AI Readiness Prediction: Not Yet Ready</div>
        <div style={{fontSize:12,color:C.soft,lineHeight:1.6}}>Based on current trajectory, the model predicts re-certification readiness by <strong style={{color:C.text}}>March 24</strong>. Competitive Positioning needs to reach ~65 (currently 52). Improving at +4pts/week.</div>
      </div>
    </div>

    {/* Competency Growth */}
    <div style={{background:C.card,borderRadius:12,padding:"14px 18px",border:`1px solid ${C.border}`}}>
      <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:10}}>Competency Growth Over Time</div>
      {[{n:"Clinical Knowledge",s:65,c:78,cl:C.emerald},{n:"Competitive Positioning",s:32,c:52,cl:C.amber},{n:"Objection Handling",s:58,c:65,cl:C.amber}].map((c,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
          <span style={{fontSize:11,color:C.text,width:140}}>{c.n}</span>
          <span style={{fontSize:10,color:C.muted,width:20}}>{c.s}</span>
          <div style={{flex:1,position:"relative",height:6,borderRadius:3,background:`${c.cl}12`}}>
            <div style={{position:"absolute",left:0,height:"100%",borderRadius:3,width:`${c.s}%`,background:`${c.cl}30`}}/>
            <div style={{position:"absolute",left:0,height:"100%",borderRadius:3,width:`${c.c}%`,background:c.cl}}/>
          </div>
          <span style={{fontSize:12,fontWeight:700,color:c.cl,width:30}}>{c.c}</span>
          <span style={{fontSize:10,color:C.emerald,fontWeight:600}}>+{c.c-c.s}</span>
        </div>
      ))}
    </div>
  </div>
);

const Q6Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      Reporting spans from <strong style={{color:C.text}}>individual rep profiles</strong> through <strong style={{color:C.text}}>team dashboards</strong> to <strong style={{color:C.text}}>regional and country-level rollups</strong>.
    </p>

    {/* Reporting Levels */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10}}>
      {[
        {level:"Individual",views:"Profile, Performance Insights, My Pathway",color:C.blue},
        {level:"Team",views:"Manager Dashboard, My Reps, Team Competencies",color:C.violet},
        {level:"Region",views:"Reports & Export with regional drill-down",color:C.teal},
        {level:"Country / Global",views:"Regional rollup table: US, Europe, APAC with sub-regions",color:C.emerald},
      ].map((r,i)=>(
        <div key={i} style={{background:C.card,borderRadius:12,padding:"14px 16px",border:`1px solid ${C.border}`,borderTop:`3px solid ${r.color}`}}>
          <div style={{fontSize:13,fontWeight:700,color:r.color,marginBottom:6}}>{r.level}</div>
          <div style={{fontSize:11,color:C.soft,lineHeight:1.5}}>{r.views}</div>
        </div>
      ))}
    </div>

    {/* Regional Rollup Sample */}
    <div style={{background:C.card,borderRadius:14,overflow:"hidden",border:`1px solid ${C.border}`}}>
      <div style={{padding:"10px 18px",borderBottom:`1px solid ${C.border}`,background:C.cardR}}>
        <span style={{fontSize:11,fontWeight:600,color:C.text}}>Regional & Country Performance Rollup (Sample)</span>
      </div>
      {[
        {r:"United States",reps:612,cert:72,echo:74,ready:71,sub:false},
        {r:"  East Region",reps:156,cert:68,echo:71,ready:68,sub:true},
        {r:"  West Region",reps:148,cert:78,echo:78,ready:76,sub:true},
        {r:"Europe",reps:156,cert:75,echo:76,ready:73,sub:false},
        {r:"  UK & Ireland",reps:48,cert:79,echo:80,ready:77,sub:true},
        {r:"Asia-Pacific",reps:79,cert:69,echo:70,ready:66,sub:false},
      ].map((row,i)=>(
        <div key={i} style={{display:"grid",gridTemplateColumns:"1.5fr .6fr .7fr .7fr .7fr",padding:`${row.sub?"7px":"10px"} 18px`,gap:8,alignItems:"center",borderBottom:`1px solid ${C.border}`,background:row.sub?"transparent":`${C.blue}03`}}>
          <span style={{fontSize:row.sub?11:12,fontWeight:row.sub?400:600,color:row.sub?C.soft:C.text}}>{row.r}</span>
          <span style={{fontSize:11,color:C.soft}}>{row.reps}</span>
          <div style={{display:"flex",alignItems:"center",gap:4}}><Bar value={row.cert} color={row.cert>=75?C.emerald:C.amber} h={4}/><span style={{fontSize:10,color:C.soft}}>{row.cert}%</span></div>
          <span style={{fontSize:11,color:row.echo>=75?C.emerald:C.amber,fontWeight:row.sub?400:600}}>{row.echo}%</span>
          <span style={{fontSize:11,color:row.ready>=70?C.emerald:C.amber,fontWeight:row.sub?400:600}}>{row.ready}%</span>
        </div>
      ))}
    </div>

    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
      {["Team Certification Status","Competency Gap Analysis","Echo Performance Summary","AI Tutor Engagement","Remediation Pipeline","Readiness Forecast","Compliance Audit","QBR Executive Summary"].map((r,i)=>(
        <Badge key={i} color={C.blue}>{r}</Badge>
      ))}
    </div>
  </div>
);

const Q7Slide = () => (
  <div style={{display:"flex",flexDirection:"column",gap:20,animation:"fadeUp .4s ease"}}>
    <p style={{fontSize:13,color:C.soft,lineHeight:1.65,margin:0}}>
      <strong style={{color:C.emerald}}>Yes — Proxa Tutor supports bidirectional CRM integration</strong> with triggers flowing both from CRM into the platform and from the platform into CRM.
    </p>

    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
      <div style={{background:C.card,borderRadius:14,padding:"16px 18px",border:`1px solid ${C.border}`}}>
        <div style={{fontSize:11,fontWeight:600,color:C.blue,marginBottom:10}}>📥 CRM → Proxa Tutor</div>
        {["New product launch → Auto-assign certification","Rep assigned new territory → Generate Pre-Call Prep for new HCPs","HCP interaction logged in Veeva → Update intel + last visit date","New hire onboarded → Auto-enroll in certification pathway","Manager change in HRIS → Reassign coaching relationships"].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:6,alignItems:"flex-start",marginBottom:6}}>
            <span style={{color:C.blue,fontSize:9,marginTop:4}}>●</span>
            <span style={{fontSize:11,color:C.soft,lineHeight:1.5}}>{t}</span>
          </div>
        ))}
      </div>
      <div style={{background:C.card,borderRadius:14,padding:"16px 18px",border:`1px solid ${C.border}`}}>
        <div style={{fontSize:11,fontWeight:600,color:C.violet,marginBottom:10}}>📤 Proxa Tutor → CRM</div>
        {["Rep earns certification → Update profile badge in Veeva/Salesforce","Rep enters remediation → Flag 'Certification In Progress' in CRM","Readiness drops below 50 → Create CRM alert for manager","Pre-Call Prep generated → Attach briefing to next CRM activity","Compliance expired → Flag non-compliant status, restrict HCP access"].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:6,alignItems:"flex-start",marginBottom:6}}>
            <span style={{color:C.violet,fontSize:9,marginTop:4}}>●</span>
            <span style={{fontSize:11,color:C.soft,lineHeight:1.5}}>{t}</span>
          </div>
        ))}
      </div>
    </div>

    <div style={{background:`${C.violet}06`,borderRadius:12,padding:"16px 18px",border:`1px solid ${C.violet}12`}}>
      <div style={{fontSize:10,fontWeight:600,color:C.violet,textTransform:"uppercase",letterSpacing:.8,marginBottom:10}}>What Reps See in Veeva / Salesforce</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
        {[
          {label:"HCP Account Page",desc:"\"Launch Proxa Tutor\" button opens AI Pre-Call Prep for that specific HCP",icon:"👤"},
          {label:"Rep Profile",desc:"Certification badges and readiness scores visible to managers directly in CRM",icon:"📋"},
          {label:"Before Scheduled Visit",desc:"CRM notification: \"AI Prep Brief available for Dr. Patel\"",icon:"📞"},
        ].map((p,i)=>(
          <div key={i} style={{background:C.card,borderRadius:8,padding:"12px",border:`1px solid ${C.border}`,textAlign:"center"}}>
            <div style={{fontSize:18,marginBottom:6}}>{p.icon}</div>
            <div style={{fontSize:11,fontWeight:600,color:C.text,marginBottom:3}}>{p.label}</div>
            <div style={{fontSize:10,color:C.muted,lineHeight:1.4}}>{p.desc}</div>
          </div>
        ))}
      </div>
    </div>

    <div style={{display:"flex",gap:8}}>
      {["Proxa Echo","Veeva CRM","Salesforce","Workday HRIS","MS Teams","SCORM/xAPI LRS"].map((t,i)=>(
        <div key={i} style={{display:"flex",alignItems:"center",gap:4,padding:"5px 10px",borderRadius:6,background:C.card,border:`1px solid ${C.border}`}}>
          <div style={{width:5,height:5,borderRadius:"50%",background:C.emerald}}/>
          <span style={{fontSize:10,color:C.emerald,fontWeight:500}}>{t}</span>
        </div>
      ))}
    </div>
  </div>
);

const ClosingSlide = () => (
  <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",minHeight:460,textAlign:"center",animation:"fadeUp .5s ease"}}>
    <div style={{width:60,height:60,borderRadius:16,background:`linear-gradient(135deg,${C.blue},${C.violet})`,display:"inline-flex",alignItems:"center",justifyContent:"center",fontSize:26,fontWeight:800,color:C.white,boxShadow:`0 8px 40px ${C.blue}25`,marginBottom:24}}>P</div>
    <h2 style={{fontSize:30,fontWeight:800,color:C.text,margin:"0 0 12px",letterSpacing:-1}}>The Only Closed-Loop Platform</h2>
    <p style={{fontSize:15,color:C.soft,margin:"0 0 36px",maxWidth:580,lineHeight:1.6}}>
      Four integrated products. One continuous loop. No other platform connects AI content creation, intelligent tutoring, AI roleplay assessment, and certified capability — all powered by AI, all in one ecosystem.
    </p>

    {/* 4-Pillar Loop */}
    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20,width:"100%",maxWidth:720}}>
      {[
        {product:"Proxa Build",label:"Create",desc:"Agentic AI framework that builds intelligent content, automates learning design, and drives operational efficiency through AI-powered processes",color:C.teal,icon:"🔨"},
        {product:"Proxa Tutor",label:"Develop",desc:"Personalized AI tutoring, adaptive quizzes, gap-aware coaching, and intelligent remediation pathways that close competency gaps",color:C.blue,icon:"⚡"},
        {product:"Proxa Echo",label:"Assess",desc:"AI-powered avatar roleplay that identifies competency gaps with behavioral precision through realistic scenario simulation",color:C.rose,icon:"🎭"},
        {product:"Certification",label:"Certify",desc:"Reps prove capability through assessed performance — not just content completion — earning certifications backed by evidence",color:C.emerald,icon:"✅"},
      ].map((s,i)=>(
        <div key={i} style={{background:C.card,borderRadius:14,padding:"20px 14px",border:`1px solid ${C.border}`,borderTop:`3px solid ${s.color}`,position:"relative"}}>
          <div style={{fontSize:24,marginBottom:6}}>{s.icon}</div>
          <div style={{fontSize:10,fontWeight:700,color:s.color,textTransform:"uppercase",letterSpacing:.8,marginBottom:2}}>{s.product}</div>
          <div style={{fontSize:15,fontWeight:700,color:C.text,marginBottom:6}}>{s.label}</div>
          <div style={{fontSize:11,color:C.soft,lineHeight:1.55}}>{s.desc}</div>
          {i<3&&<div style={{position:"absolute",right:-9,top:"50%",transform:"translateY(-50%)",fontSize:14,color:C.faint}}>→</div>}
        </div>
      ))}
    </div>

    {/* Loop Connector */}
    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:24,padding:"8px 20px",borderRadius:8,background:`${C.violet}06`,border:`1px solid ${C.violet}12`}}>
      <span style={{fontSize:11,color:C.violet}}>↻</span>
      <span style={{fontSize:11,color:C.soft}}>
        <strong style={{color:C.teal}}>Build</strong> creates content → <strong style={{color:C.blue}}>Tutor</strong> develops capability → <strong style={{color:C.rose}}>Echo</strong> assesses performance → <strong style={{color:C.emerald}}>Certification</strong> proves readiness → Loop repeats
      </span>
    </div>

    <p style={{fontSize:13,color:C.muted}}>No competitor offers this. This is a new category: <strong style={{color:C.teal}}>Intelligent Capability Development.</strong></p>
  </div>
);

const slideRenderers = {
  intro:IntroSlide, q1:Q1Slide, q2:Q2Slide, q3:Q3Slide,
  q4:Q4Slide, q5:Q5Slide, q6:Q6Slide, q7:Q7Slide, closing:ClosingSlide,
};

// ═══ MAIN APP ═══
export default function DemoWalkthrough() {
  const [current, setCurrent] = useState(0);
  const sec = sections[current];
  const Renderer = slideRenderers[sec.id];

  return (
    <div style={{width:"100vw",height:"100vh",background:C.bg,fontFamily:"'Outfit',sans-serif",color:C.text,display:"flex",overflow:"hidden"}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:${C.borderL};border-radius:10px}
        @keyframes fadeUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes pulse{0%,100%{opacity:.4}50%{opacity:.8}}
      `}</style>

      {/* Sidebar — Section Navigator */}
      <div style={{width:260,background:C.panel,borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",flexShrink:0}}>
        {/* Brand */}
        <div style={{padding:"20px 18px 16px",borderBottom:`1px solid ${C.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:9}}>
            <div style={{width:32,height:32,borderRadius:9,background:`linear-gradient(135deg,${C.blue},${C.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:800,color:C.white}}>P</div>
            <div>
              <div style={{fontSize:14,fontWeight:700,color:C.text}}>Proxa Tutor</div>
              <div style={{fontSize:9.5,color:C.muted}}>Client Demo Walkthrough</div>
            </div>
          </div>
        </div>

        {/* Section List */}
        <nav style={{flex:1,padding:"12px 8px",overflowY:"auto"}}>
          {sections.map((s,i)=>{
            const active = current===i;
            const isIntro = s.id==="intro"||s.id==="closing";
            return (
              <button key={s.id} onClick={()=>setCurrent(i)} style={{
                width:"100%",display:"flex",alignItems:"flex-start",gap:10,
                padding:"10px 12px",borderRadius:9,border:"none",marginBottom:2,
                background:active?C.blueG:"transparent",
                cursor:"pointer",textAlign:"left",fontFamily:"'Outfit',sans-serif",
                transition:"all .12s",
              }}>
                {!isIntro&&<span style={{
                  width:22,height:22,borderRadius:6,flexShrink:0,marginTop:1,
                  background:active?C.blue:`${C.muted}20`,
                  display:"flex",alignItems:"center",justifyContent:"center",
                  fontSize:10,fontWeight:700,color:active?C.white:C.muted,
                }}>{s.num}</span>}
                <div>
                  <div style={{fontSize:12,fontWeight:active?600:500,color:active?C.blue:C.soft,lineHeight:1.3}}>{s.title}</div>
                  {!isIntro&&<div style={{fontSize:10,color:C.muted,marginTop:2,lineHeight:1.3}}>{s.subtitle}</div>}
                </div>
              </button>
            );
          })}
        </nav>

        {/* Progress */}
        <div style={{padding:"12px 18px",borderTop:`1px solid ${C.border}`}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
            <span style={{fontSize:10,color:C.muted}}>Progress</span>
            <span style={{fontSize:10,color:C.blue,fontWeight:600}}>{current+1}/{sections.length}</span>
          </div>
          <Bar value={((current+1)/sections.length)*100} color={C.blue} h={4}/>
        </div>
      </div>

      {/* Main Content */}
      <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
        {/* Top Bar */}
        <div style={{height:52,borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",padding:"0 28px",justifyContent:"space-between",flexShrink:0,background:C.panel}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            {sec.num&&<Badge color={C.blue}>{sec.num}</Badge>}
            <h1 style={{fontSize:15,fontWeight:600,color:C.text,margin:0}}>{sec.title}</h1>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <button onClick={()=>setCurrent(Math.max(0,current-1))} disabled={current===0} style={{
              padding:"6px 14px",borderRadius:7,border:`1px solid ${current>0?C.border:C.border}`,
              background:current>0?C.card:"transparent",color:current>0?C.soft:C.faint,
              fontSize:11,fontWeight:600,cursor:current>0?"pointer":"default",fontFamily:"'Outfit',sans-serif",
            }}>← Prev</button>
            <button onClick={()=>setCurrent(Math.min(sections.length-1,current+1))} disabled={current===sections.length-1} style={{
              padding:"6px 14px",borderRadius:7,border:"none",
              background:current<sections.length-1?C.blue:C.faint,color:C.white,
              fontSize:11,fontWeight:600,cursor:current<sections.length-1?"pointer":"default",fontFamily:"'Outfit',sans-serif",
            }}>Next →</button>
          </div>
        </div>

        {/* Content Area */}
        <div style={{flex:1,overflow:"auto",padding:"28px 32px 40px"}} key={sec.id}>
          {/* Client Question Banner */}
          {sec.clientQ&&(
            <div style={{
              background:`${C.blue}06`,borderRadius:12,padding:"14px 18px",
              border:`1px solid ${C.blue}15`,marginBottom:24,
              display:"flex",gap:10,alignItems:"flex-start",
            }}>
              <span style={{fontSize:14,flexShrink:0,marginTop:1}}>💬</span>
              <div>
                <div style={{fontSize:10,fontWeight:600,color:C.blue,textTransform:"uppercase",letterSpacing:.8,marginBottom:4}}>Client Question</div>
                <div style={{fontSize:13,color:C.soft,lineHeight:1.6,fontStyle:"italic"}}>"{sec.clientQ}"</div>
              </div>
            </div>
          )}

          {/* Slide Content */}
          {Renderer && <Renderer/>}
        </div>
      </div>
    </div>
  );
}
